# Venox Bot
A bot used by [@srnyx](https://github.com/srnyx) (https://srnyx.xyz/) and [@ChrizxzFTW](https://github.com/Chrizxz) (https://chrizftw.cf/) in their administration.

[![Website](https://img.srnyx.xyz/r/banner_round.png)](https://v.srnyx.xyz)
